package OopsConcepts;

public class Browser {

	String var = "browserName";
	String var1 = "browerVersion";

	public void openURL() {
		System.out.println("open URL");
	}

	public void closeBrowser() {
		System.out.println("close the browser");
	}

	public void navigateBack() {
		System.out.println("navigateback");
	}

}
